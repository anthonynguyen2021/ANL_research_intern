# structuredbandits20

This directory will contain bib files useful for this project. Several bib files can be used, with the recommendation being to add new things to project.bib.