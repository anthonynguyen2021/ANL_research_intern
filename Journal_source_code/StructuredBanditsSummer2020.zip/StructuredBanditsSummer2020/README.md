# structuredbandits20

This is for work with Anthony Nguyen on randomized directional derivative methods for structure-exploiting optimization.