# structuredbandits20

This directory will contain source code for documents (journal, papers, slides for SASSy talk, etc.) developed under this project. Stefan benefits from having a makefile so as to know how to build various documents.
