# structuredbandits20

This directory will contain LaTeX source code for Anthony's daily Journal at ANL.