# structuredbandits20

This directory will contain python scripts. NOTE: these scripts are outdated. See the root of this project in /Python_code/ folder.